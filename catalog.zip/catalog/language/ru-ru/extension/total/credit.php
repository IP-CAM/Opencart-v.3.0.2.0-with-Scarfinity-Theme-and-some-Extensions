<?php
// Text
$_['text_credit']   = 'Кредит Магазина';
$_['text_order_id'] = '№ Заказа: %s';

