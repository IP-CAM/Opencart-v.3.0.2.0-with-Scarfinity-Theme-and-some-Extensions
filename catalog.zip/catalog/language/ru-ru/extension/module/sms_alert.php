<?php

$_['text_telephone_validation'] = 'scarfinity.ru - telephone validation';
$_['text_order']  = 'Получен заказ № ';
$_['text_registration'] = 'SCARFINITY.RU - Спасибо за регистрацию! Ваш пароль: ';
$_['text_registration1'] = 'Spasibo za registraciyu! Vash parol: ';
$_['text_order_post']  = 'SCARFINITY.RU - Ваш заказ принят! №';

