<?php
// Text
$_['text_title']  = 'Почта';
$_['text_description'] = 'EMS Почта России';

