<?php
// Text
$_['text_title']  = 'Автовокзал';
$_['text_description'] = 'Автовокзал г. Новосибирск';

