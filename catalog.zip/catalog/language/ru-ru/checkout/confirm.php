<?php
// Heading
$_['heading_title']        = 'Подтверждение заказа и оплата';

// Text
$_['text_basket']          = 'Корзина';
$_['text_checkout']        = 'Оформить заказ';
$_['text_requisites']      = 'Доставка и оплата';
$_['text_confirm']         = 'Подтверждение заказа';

