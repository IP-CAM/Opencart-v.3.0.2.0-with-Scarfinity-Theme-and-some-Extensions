$('#cart-button-next').on('click', function() {
    location = checkoutLocation;
});